
//esnkron
/*
export function draw(min,max,n){
    min = Number(min) || 1;
    max = Number(max) || 50;
    n =Number(n) || 6;
    let numbers = [];
    while(numbers.length<6){
        let r=Math.floor(Math.random()*(max-min))+min;
        if(numbers.indexOf(r)<0){
            numbers.push(r);
        }
    }
    numbers.sort((x,y)=>x-y);
    return numbers;
}
*/
//async
export function draw(min,max,n) {
    return new Promise((resolve,reject)=>{

        min = Number(min) || 1;
        max = Number(max) || 50;
        n =Number(n) || 6;
        let numbers = [];
        while(numbers.length<6){
            let r=Math.floor(Math.random()*(max-min))+min;
            if(numbers.indexOf(r)<0){
                numbers.push(r);
            }
        }
        numbers.sort((x,y)=>x-y);
        resolve(numbers);
    });
}