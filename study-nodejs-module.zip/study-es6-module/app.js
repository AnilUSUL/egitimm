import  {draw} from './lottery.js';

class AppViewModel{
    constructor(){
        this.numbers=ko.observable();
        this.drawNumbers=this.drawNumbers.bind(this);
        draw(1,50,6).then(numbers=>this.numbers(numbers));
    }
    drawNumbers(){
        draw(1,50,6).then(numbers=>this.numbers(numbers));
    }
}

$(document).ready(()=>{
    let vm = new AppViewModel();
    ko.applyBindings(vm);
})