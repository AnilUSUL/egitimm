let port = 9001;

let express = require('express');
let bodyParser = require('body-parser');
let logger = require('morgan');
let lottery = require('lottery');
let app = express();

app.use(bodyParser.json());
app.use(logger('dev'));

app.get('/numbers',(req,res)=>{
    let min = req.query.min;
    let max = req.query.max;
    let n = req.query.n;
    res.set('Content-Type','application/json');
    let numbers = lottery.draw(min,max,n);
    console.log(min)
    console.log(max)
    console.log(n)
    console.log(numbers)
    res.set(200).send(numbers);
})

app.listen(port);
console.log("Server is running at port ".concat(port));